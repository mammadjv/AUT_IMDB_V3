# AUT_IMDB_V2
Third Project of IE(Internet engineering) Course
